
public class Lady {
	public int linePosition;
	public String chickName;
	
	public Lady(int linePosition, String chickName) {
		this.linePosition = linePosition;
		this.chickName = chickName;
	}
	
	
}
